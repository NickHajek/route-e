| Q             | A
| ------------- | ---
| Branch?       | master / x
| Bug fix?      | yes/no
| New feature?  | yes/no
| Tests pass?   | yes/no
| Fixed issues  | #... <!-- number of issue if any -->
| License       | MIT

<!--
- Replace this comment by a description of what your PR is solving.
-->
